#!/bin/bash

coma="\""
while read sector; do
	echo "c($coma$(cat raw  | cut -f 1,4 | grep "$sector" | cut -f 1 | sed ':a;N;$!ba;s/\n/\", \"/g')$coma)" > "${sector}"
	echo $sector
done < sectors
