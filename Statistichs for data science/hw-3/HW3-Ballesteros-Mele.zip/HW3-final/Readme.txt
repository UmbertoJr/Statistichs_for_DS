Hi,

we put two files of interest:
fast-compile.Rmd  and slow-compile.Rmd

The difference is that in the slow-compile file, for the last exercise we use more than 400 stocks, so it can be slow to run, instead, you can run the fast compile version that uses samples of 20 stocks from each GICS sector. Anyhow, both versions are already compiled too in the folder.
